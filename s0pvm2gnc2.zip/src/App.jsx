export default function App() {
  return (
    <div className="card">
    <div className="image">
    </div>
    <main>
      <h1>Jihan Chowdhury</h1>
      <h3>Frontend Developer</h3>
      <h4>jihan.website</h4>

      <div className="emli">
      <span className="email">Email</span>
      <span className="linkedin">Linkedin</span>
      </div>

      <h2>About</h2>
      <p>im the goat</p>

      <h2>Interests</h2>
      <p>im the goat</p>
    </main>
    <footer>
    <h5>social</h5>
    <h5>social</h5>
    <h5>social</h5>
    <h5>social</h5>
    
    </footer>
    </div>
  )
}
